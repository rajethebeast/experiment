import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vnavbar',
  templateUrl: './vnavbar.component.html',
  styleUrls: ['./vnavbar.component.css']
})
export class VnavbarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
