import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cnavbar',
  templateUrl: './cnavbar.component.html',
  styleUrls: ['./cnavbar.component.css']
})
export class CnavbarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
