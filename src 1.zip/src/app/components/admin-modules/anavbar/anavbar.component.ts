import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-anavbar',
  templateUrl: './anavbar.component.html',
  styleUrls: ['./anavbar.component.css']
})
export class AnavbarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
