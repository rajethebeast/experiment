export class VendorInfo{
    id?:number;
    name?: string;
    address?:string;
    email?: string;
    role?: string;
    contact?: string;
    password?: string;
    username?:string
  }