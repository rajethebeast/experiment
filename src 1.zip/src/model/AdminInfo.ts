export class AdminInfo{
    id?: number;
    name?: string;
    email?: string;
    password?: string;
}