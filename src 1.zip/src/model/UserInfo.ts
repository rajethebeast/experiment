export class UserInfo{
    id?:number;
    name?: string;
    email?: string;
    password?: string;
    role?: string;
  }