export class Vendor{
    id : number;
    name : string;
    address : string;
    contact : string;
    email : string;
 }
 
 export class Policy{
    id : number;
     name : string;
 }
 