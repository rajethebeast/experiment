export class CustomerInfo{
    id?: number;
    firstName?: string;
    lastName?: string;
    dob?: string;
    salary?: number;
    address?: string;
    contactNo?: string;
    email?: string;
    panNo?: string;
    employerType?: string;
    employerName?: string;
    username?:string;
    password?: string;
}
